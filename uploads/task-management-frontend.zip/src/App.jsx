import {useState} from "react";
import axios from "axios";

const API="http://127.0.0.1:5000";

export default function App(){
  const [email,setEmail]=useState("");
  const [password,setPassword]=useState("");
  const [token,setToken]=useState(localStorage.getItem("token")||"");
  const [tasks,setTasks]=useState([]);

  const login=async()=>{
    const res=await axios.post(`${API}/api/v1/auth/login`,{email,password});
    localStorage.setItem("token",res.data.token);
    setToken(res.data.token);
    alert("Login successful");
  };

  const loadTasks=async()=>{
    const res=await axios.get(`${API}/api/v1/tasks`,{
      headers:{Authorization:`Bearer ${token}`}
    });
    setTasks(res.data);
  };

  return (
    <div style={{maxWidth:"800px",margin:"40px auto",fontFamily:"Arial"}}>
      <h1>Task Management Dashboard</h1>

      <div>
        <h3>Login</h3>
        <input placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
        <input placeholder="Password" type="password" value={password} onChange={e=>setPassword(e.target.value)} />
        <button onClick={login}>Login</button>
      </div>

      <hr/>

      <button onClick={loadTasks}>Load Tasks</button>

      <ul>
        {tasks.map(t=>(
          <li key={t.id}>
            <strong>{t.title}</strong> - {t.description}
          </li>
        ))}
      </ul>
    </div>
  );
}
